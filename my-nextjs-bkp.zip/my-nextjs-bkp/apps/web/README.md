# Web Application

This is the main Next.js application in the monorepo.

## Getting Started

```bash
# Install dependencies (from root)
pnpm install

# Start development server
pnpm dev

# Build for production
pnpm build

# Start production server
pnpm start
