import { SearchWrapper } from '~/components/layout/search'

export default function SearchPage() {
  return <SearchWrapper />
}
