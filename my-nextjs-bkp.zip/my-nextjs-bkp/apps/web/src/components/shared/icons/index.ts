export { EmailIcon, LocationIcon, PhoneIcon } from './footer-icons'
export { FacebookIcon, InstagramIcon, TwitterIcon, YouTubeIcon } from './social-icons'
