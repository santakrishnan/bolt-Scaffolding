"use client";

import { MyGarageCards } from '~/components/features/mygarage/my-garage-cards';
import { CarCard } from '~/components/features/mygarage/car-card';
import React, { useState } from 'react';
import { TestDriveBanner } from '~/components/features/mygarage/test-drive-banner';
import { VehicleStatsGrid } from '~/components/features/mygarage/vehicle-stats-grid';
import { TransmissionIcon, EngineIcon, BatteryIcon, MPGIcon } from '@tfs-ucmp/ui';

interface MyGarageClientProps {
    cars: any[];
}


export function MyGarageClient({ cars }: MyGarageClientProps) {
    // Track wishlisted state for each car by id
    const [wishlisted, setWishlisted] = useState(() => {
        const initial: Record<string, boolean> = {};
        cars.forEach(car => { initial[car.id] = false; });
        return initial;
    });

    // Only show wishlisted cars in savedVehicles
    const [savedVehicles, setSavedVehicles] = useState(() =>
        cars
            .filter(car => wishlisted[car.id])
            .map(car => ({
                imageUrl:
                    typeof car.image === 'string' && car.image.startsWith('/images/')
                        ? car.image
                        : car.image,
                title: car.title,
                price: `$${car.price.toLocaleString()}`,
                miles: car.odometer
            }))
    );

    // Keep savedVehicles in sync with wishlisted
    React.useEffect(() => {
        setSavedVehicles(
            cars
                .filter(car => wishlisted[car.id])
                .map(car => ({
                    imageUrl:
                        typeof car.image === 'string' && car.image.startsWith('/images/')
                            ? car.image
                            : car.image,
                    title: car.title,
                    price: `$${car.price.toLocaleString()}`,
                    miles: car.odometer
                }))
        );
    }, [wishlisted, cars]);

    const handleRemoveSavedVehicle = (idx: number) => {
        const vehicle = savedVehicles[idx];
        // Find the car in cars that matches this vehicle
        const car = cars.find(
            c =>
                (typeof c.image === 'string' && (c.image === vehicle.imageUrl.replace('/assets', '') || `/assets${c.image}` === vehicle.imageUrl)) &&
                c.title === vehicle.title &&
                `$${c.price.toLocaleString()}` === vehicle.price &&
                c.odometer === vehicle.miles
        );
        if (car) {
            setWishlisted(w => ({ ...w, [car.id]: false }));
        }
    };

    return (
        <div className="min-h-screen" style={{ background: '#F4F4F4' }}>
            <div className="w-full max-w-6xl mx-auto mb-10">
                <MyGarageCards
                    savedVehicles={savedVehicles}
                    recentSearches={[
                        { search: 'Hybrid SUV under 35k blue gasoline' },
                        { search: 'Toyota RAV4 under 35k near me', highlighted: true },
                        { search: 'Highlander under 35k with 3rd row' },
                        { search: 'Looking for a used Toyota SUV under $35k with low miles, AWD, and good fuel eco...' },
                        { search: 'Hybrid SUV with Apple CarPlay' },
                        { search: 'Tacoma low mileage', disabled: true },
                    ]}
                    financing={{ prequalified: true }}
                    tradeOffer={{ imageUrl: '/images/vehicles/offer.png', title: '2019 Audi A7', price: '$15,500', miles: '68,150 miles', expiresIn: '2 days' }}
                    onRemoveSavedVehicle={handleRemoveSavedVehicle}
                />
            </div>

            <h2 className="w-full max-w-6xl px-2 mx-auto mb-6 text-xl font-semibold text-left">Best Matches for you</h2>
            <div className="grid max-w-6xl grid-cols-4 gap-4 px-2 mx-auto">
                {cars.map((car) => (
                    <CarCard
                        key={car.id}
                        title={car.title}
                        price={car.price}
                        image={car.image}
                        miles={car.miles}
                        odometer={car.odometer}
                        match={car.match}
                        labels={car.labels}
                        oldPrice={car.oldPrice}
                        isFavorite={wishlisted[car.id]}
                        onFavoriteToggle={() => setWishlisted(w => ({ ...w, [car.id]: !w[car.id] }))}
                    />
                ))}
            </div>

            <div className="w-full max-w-6xl mx-auto mb-10">
                <VehicleStatsGrid
                    cards={[
                        {
                            icon: <EngineIcon size={40} className="text-[#EB0D1C]" />,
                            title: 'Engine',
                            count: '2.5L',
                        },
                        {
                            icon: <BatteryIcon size={40} className="text-[#EB0D1C]" />,
                            title: 'Battery',
                            count: 'Hybrid',
                        },
                        {
                            icon: <MPGIcon size={40} className="text-[#EB0D1C]" />,
                            title: 'MPG',
                            count: '40',
                        },
                        {
                            icon: <TransmissionIcon size={40} className="text-[#EB0D1C]" />,
                            title: 'Transmission',
                            count: 'Automatic',
                        },
                    ]}
                />
            </div>

            <div className="w-full mx-auto mt-20 mb-10">
                <TestDriveBanner imageUrl="/images/vehicles/testd.png" />
            </div>
        </div>
    );
}
