import { MyGarageClient } from '~/components/layout/my-garage/my-garageclient';
import { fetchGarageCars } from '~/lib/my-garage/fetchGarageCars';

export async function MyGarageWrapper() {
    const cars = await fetchGarageCars();
    return <MyGarageClient cars={cars} />;
}
