import React from "react";

// Fallback ScrollArea if not available in UI primitives
import { ScrollArea } from "@tfs-ucmp/ui";

export type SavedVehicleCardProps = {
    imageUrl: string;
    title: string;
    price: string;
    miles: string;
    onRemove?: () => void;
};

export const SavedVehicleCard: React.FC<SavedVehicleCardProps> = ({ imageUrl, title, price, miles, onRemove }) => (
    <div className="flex items-center gap-3 py-2 border-b last:border-b-0">
        <img src={imageUrl} alt={title} className="object-cover w-16 h-10 rounded" />
        <div className="flex flex-col flex-1">
            <span className="text-sm font-semibold">{title}</span>
            <span className="text-[#EB0D1C] text-xs">{price}</span>
            <span className="text-xs text-gray-500">{miles}</span>
        </div>
        <button className="ml-2 text-black hover:text-[#EB0D1C] transition-colors p-1 rounded-full focus:outline-none" aria-label="Remove saved vehicle" onClick={onRemove}>
            <picture>
                <source srcSet="/images/garage/cross.svg" type="image/svg+xml" />
                <img src="/images/garage/cross.svg" alt="Remove" width={10} height={10} />
            </picture>
        </button>
    </div>
);

export type RecentSearchCardProps = {
    search: string;
    highlighted?: boolean;
    disabled?: boolean;
    onRemove?: () => void;
};

export const RecentSearchCard: React.FC<RecentSearchCardProps> = ({ search, highlighted, disabled, onRemove }) => (
    <div className={`flex items-center justify-between py-2 border-b last:border-b-0 ${highlighted ? 'text-[#EB0D1C]' : ''} ${disabled ? 'text-gray-400' : ''}`}>
        <span className="text-sm">{search}</span>
        {!disabled && (
            <button onClick={onRemove} className="ml-2 text-black hover:text-[#EB0D1C] transition-colors p-1 rounded-full focus:outline-none" aria-label="Remove recent search">
                <picture>
                    <source srcSet="/images/garage/cross.svg" type="image/svg+xml" />
                    <img src="/images/garage/cross.svg" alt="Remove" width={10} height={10} />
                </picture>
            </button>
        )}
    </div>
);

export type FinancingCardProps = {
    prequalified: boolean;
    onBuyOnline?: () => void;
};

export const FinancingCard: React.FC<FinancingCardProps> = ({ prequalified, onBuyOnline }) => (
    <div className="flex flex-col gap-2 p-4 bg-white rounded-lg shadow">
        <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">Your Financing</span>
            {prequalified && <span className="px-2 py-1 text-xs text-green-700 bg-green-100 rounded">Pre-qualified</span>}
        </div>
        <div className="flex items-center gap-2">
            <span className="bg-[#EB0D1C] text-white rounded-full w-7 h-7 flex items-center justify-center font-bold text-xs">27</span>
            <span className="text-xs">You are pre-qualified<br />See real monthly payments on every vehicle</span>
        </div>
        <button className="bg-[#EB0D1C] text-white rounded-full py-2 font-semibold mt-2">Buy Online</button>
    </div>
);

export type TradeOfferCardProps = {
    imageUrl: string;
    title: string;
    price: string;
    miles: string;
    expiresIn: string;
    onShopWithTradeIn?: () => void;
};

export const TradeOfferCard: React.FC<TradeOfferCardProps> = ({ imageUrl, title, price, miles, expiresIn, onShopWithTradeIn }) => (
    <div className="flex flex-col gap-2 p-4 bg-white rounded-lg shadow">
        <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">Sell/Trade Offer</span>
            <span className="px-2 py-1 text-xs text-gray-700 bg-gray-200 rounded">Expires in {expiresIn}</span>
        </div>
        <div className="flex items-center gap-2">
            <img src={imageUrl} alt={title} className="object-cover w-16 h-10 rounded" />
            <div className="flex flex-col">
                <span className="text-xs font-semibold">{title}</span>
                <span className="text-[#EB0D1C] text-xs">{price}</span>
                <span className="text-xs text-gray-500">{miles}</span>
            </div>
        </div>
        <button className="bg-[#EB0D1C] text-white rounded-full py-2 font-semibold mt-2">Shop With Your Trade-In</button>
    </div>
);

export type MyGarageCardsProps = {
    savedVehicles: SavedVehicleCardProps[];
    recentSearches: RecentSearchCardProps[];
    financing: FinancingCardProps;
    tradeOffer: TradeOfferCardProps;
};

export const MyGarageCards: React.FC<MyGarageCardsProps & { onRemoveSavedVehicle?: (idx: number) => void }> = ({ savedVehicles, recentSearches, financing, tradeOffer, onRemoveSavedVehicle }) => (
    <div className="flex w-full gap-6">
        <div className="bg-white rounded-lg shadow flex-1 min-w-[260px] relative">
            <div className="flex items-center justify-between p-4 mb-2">
                <span className="text-sm font-semibold">Saved Vehicles ({savedVehicles.length})</span>
                <button className="text-[#EB0D1C] text-xs font-semibold">View All</button>
            </div>
            <ScrollArea className="h-[220px] p-4 w-full absolute left-0 right-0">
                {savedVehicles.map((props, idx) => (
                    <SavedVehicleCard key={idx} {...props} onRemove={onRemoveSavedVehicle ? () => onRemoveSavedVehicle(idx) : undefined} />
                ))}
            </ScrollArea>
        </div>
        <div className="bg-white rounded-lg shadow p-4 flex-1 min-w-[260px]">
            <span className="block p-4 mb-2 text-sm font-semibold">Recent Searches</span>
            <ScrollArea className="h-[220px] p-4 w-full">
                {recentSearches.map((props, idx) => <RecentSearchCard key={idx} {...props} />)}
            </ScrollArea>
        </div>
        <div className="flex flex-col gap-4 flex-1 min-w-[260px]">
            <FinancingCard {...financing} />
            <TradeOfferCard {...tradeOffer} />
        </div>
    </div>
);
