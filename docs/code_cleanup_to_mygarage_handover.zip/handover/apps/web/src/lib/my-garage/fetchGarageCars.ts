import mockCars from '../../data/mock-cars.json';

export function fetchGarageCars() {
    // You can add filtering or transformation logic here if needed
    return mockCars;
}
