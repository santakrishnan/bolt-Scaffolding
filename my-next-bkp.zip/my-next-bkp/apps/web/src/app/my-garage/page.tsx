
import { MyGarageWrapper } from '~/components/layout/my-garage';

export default function MyGaragePage() {
    return <MyGarageWrapper />;
}
