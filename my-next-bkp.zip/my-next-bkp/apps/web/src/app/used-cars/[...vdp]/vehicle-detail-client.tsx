"use client";

import {
  DealerNotesSection,
  VehicleDetailsTabs,
  VehiclePDP,
  VehicleRating,
} from "~/components/features/vdp";
import type { VdpPageData } from "~/lib/data/vehicle";
import { capitalize } from "~/lib/formatters";
import type { VdpParams } from "~/lib/routes";

interface VehicleDetailClientProps {
  vehicle: VdpParams;
  pageData: VdpPageData;
}

export function VehicleDetailClient({
  vehicle,
  pageData,
}: VehicleDetailClientProps) {
  const {
    vehicle: vehicleData,
    specs,
    features,
    pricing,
    history,
    rating,
  } = pageData;

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <main className="flex-1">
        {/* Vehicle PDP Section */}
        <div className="container mx-auto py-12 sm:px-6 lg:px-8">
          <VehiclePDP vehicle={vehicleData} />
        </div>

        {/* Tabs and Rating section - full width background */}
        <div className="mb-12 w-full bg-muted py-6">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <VehicleDetailsTabs
              features={features}
              historyData={history}
              pricingData={pricing}
              showInspectionSection={true}
              specs={specs}
            />

            {/* Rating Section */}
            <div className="mt-6">
              <VehicleRating
                distribution={rating.distribution}
                rating={rating.rating}
                reviewCount={rating.reviewCount}
                title={`${vehicle.year} ${capitalize(vehicle.make)} ${capitalize(vehicle.model)}`}
              />
            </div>
          </div>
        </div>

        {/* Dealer Notes & Info Section */}
        <DealerNotesSection
          onReviewsClick={() => {
            // TODO: implement reviews navigation
          }}
          onTestDriveClick={() => {
            // TODO: implement test drive scheduling
          }}
        />
      </main>
    </div>
  );
}
