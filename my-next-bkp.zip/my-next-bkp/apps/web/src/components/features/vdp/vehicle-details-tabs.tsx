"use client";

import {
  BatteryIcon,
  Button,
  ColorsIcon,
  cn,
  DamageReportIcon,
  EngineIcon,
  MarkerPinIcon,
  MileageIcon,
  MPGIcon,
  NoDamageIcon,
  OdometerIcon,
  PreviousOwnersIcon,
  ServiceHistoryIcon,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  TransmissionIcon,
  TypeOwnersIcon,
  VectorRightOutlineIcon,
} from "@tfs-ucmp/ui";
import { ExternalLink, Eye } from "lucide-react";
import type { ReactNode } from "react";
import Image from "next/image";
import type {
  FeatureCategory,
  HistoryData,
  PricingData,
  VehicleSpecData,
} from "~/lib/data/vehicle";
import { HistoryStatCard } from "./history-stat-card";
import { InspectionCard } from "./inspection-card";
import { PriceRangeMeter } from "./price-range-meter";

interface VehicleDetailsTabsProps {
  className?: string;
  specs: VehicleSpecData[];
  features: FeatureCategory[];
  pricingData: PricingData;
  historyData: HistoryData;
  showInspectionSection?: boolean;
}

/** Map a spec key to the corresponding icon component */
const specIconMap: Record<string, ReactNode> = {
  engine: <EngineIcon className="text-gray-400" size={20} />,
  "interior-color": <ColorsIcon className="text-gray-400" size={20} />,
  "exterior-color": <ColorsIcon className="text-gray-400" size={20} />,
  mpg: <MPGIcon className="text-gray-400" size={20} />,
  mileage: <MileageIcon className="text-gray-400" size={20} />,
  location: <MarkerPinIcon className="text-gray-400" size={20} />,
  "fuel-type": <BatteryIcon className="text-gray-400" size={20} />,
  drivetrain: <BatteryIcon className="text-gray-400" size={20} />,
  transmission: <TransmissionIcon className="text-gray-400" size={20} />,
};

/** Shared className for all tab triggers */
const tabTriggerClassName =
  "flex-shrink-0 whitespace-nowrap rounded-none border-transparent border-b-2 bg-transparent px-0 pb-3 font-normal text-gray-600 data-[state=active]:border-[#EB0A1E] data-[state=active]:bg-transparent data-[state=active]:font-semibold data-[state=active]:text-gray-900 data-[state=active]:shadow-none";

/**
 * FeatureItem - Helper component for displaying a feature with checkmark
 */
function FeatureItem({ text }: { text: string }) {
  return (
    <div className="flex items-start gap-2">
      <div className="mt-0.5 flex-shrink-0">
        <VectorRightOutlineIcon className="text-gray-900" size={20} />
      </div>
      <span className="text-sm text-gray-900">{text}</span>
    </div>
  );
}

/**
 * VehicleDetailsTabs Component
 * Displays vehicle information organized in tabs
 */
export function VehicleDetailsTabs({
  className,
  specs,
  features,
  pricingData,
  historyData,
  showInspectionSection = false,
}: VehicleDetailsTabsProps) {
  return (
    <div className={cn("w-full", className)}>
      <Tabs className="w-full" defaultValue="overview">
        <div className="relative w-full mb-6 border-b border-gray-200">
          <div
            className="px-1 overflow-x-auto md:overflow-x-visible md:px-0"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
              WebkitOverflowScrolling: "touch",
            }}
          >
            <TabsList className="flex h-auto gap-8 p-0 bg-transparent border-0 rounded-none flex-nowrap">
              <TabsTrigger className={tabTriggerClassName} value="overview">
                Overview
              </TabsTrigger>
              <TabsTrigger className={tabTriggerClassName} value="features">
                Features & Details
              </TabsTrigger>
              <TabsTrigger className={tabTriggerClassName} value="pricing">
                Pricing
              </TabsTrigger>
              <TabsTrigger className={tabTriggerClassName} value="history">
                History
              </TabsTrigger>
            </TabsList>
          </div>
        </div>

        {/* Overview Tab Content */}
        <TabsContent className="mt-0" value="overview">
          <div className="p-6 rounded-lg">
            {/* Header with title and button */}
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold sm:text-xl">Overview</h3>
              <Button
                className="rounded-full border-black px-4 py-1.5 text-sm hover:bg-gray-100"
                variant="outline"
              >
                View All Specs
              </Button>
            </div>

            {/* Specs Card */}
            <div className="p-6 bg-white rounded-lg shadow-sm">
              {/* Mobile layout */}
              <div className="block divide-y divide-gray-200 md:hidden">
                {specs.map((spec, index) => (
                  <div
                    className="flex items-center py-4 first:pt-0 last:pb-0"
                    key={index}
                  >
                    <div className="flex items-center flex-1 gap-3">
                      <span className="mt-0.5">{specIconMap[spec.key]}</span>
                      <span className="text-sm text-gray-500">
                        {spec.label}
                      </span>
                    </div>
                    <span className="min-w-[90px] text-right font-semibold text-gray-900 text-sm">
                      {spec.value}
                    </span>
                  </div>
                ))}
              </div>
              {/* Desktop layout */}
              <div className="hidden grid-cols-1 gap-6 md:grid md:grid-cols-2 lg:grid-cols-3">
                {specs.map((spec, index) => (
                  <div
                    className="flex items-start gap-3 pb-6 border-b border-gray-200"
                    key={index}
                  >
                    <div className="mt-0.5">{specIconMap[spec.key]}</div>
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">
                        {spec.label}
                      </span>
                      <span className="text-base font-medium text-gray-900">
                        {spec.value}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Features & Details Tab Content */}
        <TabsContent className="mt-0" value="features">
          <div className="p-6 rounded-lg">
            {/* Header with title and button */}
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-semibold">Key Features</h3>
              <Button
                className="border-black rounded-full hover:bg-gray-100"
                variant="outline"
              >
                View All Features
              </Button>
            </div>

            {/* Features Grid - 4 columns */}
            <div className="p-6 bg-white rounded-lg">
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
                {features.map((category) => (
                  <div key={category.name}>
                    <h4 className="mb-4 text-base font-semibold">
                      {category.name}
                    </h4>
                    <div className="space-y-3">
                      {category.features.map((feature) => (
                        <FeatureItem key={feature} text={feature} />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Pricing Tab Content */}
        <TabsContent className="mt-0" value="pricing">
          {/* Header with stats */}
          <div className="px-6 pt-6 pb-4 rounded-t-lg">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <h3 className="text-2xl font-bold">Pricing</h3>
              <div className="flex flex-wrap items-center gap-4 text-sm sm:gap-6">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">
                    <span className="font-semibold text-gray-900">
                      {pricingData.daysOnSite} days
                    </span>{" "}
                    on Arrow
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">
                    <span className="font-semibold text-gray-900">
                      {pricingData.views}
                    </span>{" "}
                    Views
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">
                    <span className="font-semibold text-gray-900">
                      {pricingData.saves}
                    </span>{" "}
                    saves
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Price Analysis Section - white background */}
          <div className="px-6 py-6">
            <div className="px-8 py-8 bg-white rounded-lg">
              {/* Price badge and description + Price Range Meter side by side */}
              <div className="flex flex-col items-start gap-8 lg:flex-row lg:items-center lg:gap-12">
                {/* Left: Text content */}
                <div className="flex-shrink-0">
                  <div className="flex items-center gap-3 mb-3">
                    <h4 className="text-xl font-semibold">
                      This vehicle is an
                    </h4>
                    <span className="inline-flex items-center gap-1 rounded-md bg-green-500 px-3 py-1.5 font-semibold text-sm text-white">
                      <span className="text-xs">✓</span> Excellent Price
                    </span>
                  </div>
                  <p className="text-base text-gray-900">
                    This vehicle is below the current average market range.
                  </p>
                </div>

                {/* Right: Price Range Meter */}
                <div className="flex-1 w-full lg:max-w-2xl">
                  <PriceRangeMeter
                    avgPrice={pricingData.avgPrice}
                    currentPrice={pricingData.currentPrice}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Price History Accordion - separate section */}
          <div className="px-6 pb-6 rounded-b-lg">
            <div className="bg-white rounded-lg">
              <button
                className="flex items-center justify-between w-full p-6 text-left transition-colors hover:bg-gray-50"
                type="button"
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-10 h-10 bg-gray-100 rounded-full">
                    <Image
                      alt=""
                      aria-hidden="true"
                      className="w-5 h-5"
                      height={20}
                      src="/images/vdp/price_icon.svg"
                      width={20}
                    />
                  </div>
                  <span className="text-lg font-semibold">Price History</span>
                </div>
                {/* <ChevronDown className="w-5 h-5 text-gray-500" /> */}
              </button>
            </div>
          </div>
        </TabsContent>

        {/* History Tab Content */}
        <TabsContent className="mt-0" value="history">
          <div className="p-6 rounded-lg">
            {/* Header with VIN, Vehicle Description and View Report button */}
            <div className="flex flex-col justify-between gap-6 pb-6 mb-8 border-b border-gray-200 md:flex-row md:items-stretch md:border-b-0 md:pb-0">
              <div className="flex flex-col justify-center flex-shrink-0 md:border-gray-200 md:border-r md:pr-6">
                <h3 className="mb-1 text-xl font-bold">Vehicle History</h3>
                <p className="text-xs text-gray-600">
                  VIN:{" "}
                  <span className="font-medium text-gray-900">
                    {historyData.vin}
                  </span>
                </p>
              </div>
              <div className="flex items-center flex-1 text-sm text-gray-700 md:border-gray-200 md:border-r md:px-6">
                {historyData.vehicleDescription}
              </div>
              <div className="flex items-center flex-shrink-0 md:pl-6">
                <Button
                  className="border-black rounded-full hover:bg-gray-100"
                  variant="outline"
                >
                  View Full Report
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>

            {/* History Stats - Single Card */}
            <div className="p-6 bg-white border border-gray-200 rounded-lg">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                <HistoryStatCard
                  icon={<NoDamageIcon className="text-red-500" size={20} />}
                  label="No Damage"
                  value={`${historyData.damageReported} Damage Reported`}
                />
                <HistoryStatCard
                  icon={
                    <PreviousOwnersIcon className="text-red-500" size={20} />
                  }
                  label="Previous Owners"
                  value={`${historyData.previousOwners} Owners`}
                />
                <HistoryStatCard
                  icon={
                    <ServiceHistoryIcon className="text-red-500" size={20} />
                  }
                  label="Service History"
                  value={`${historyData.servicesOnRecord} Services on Record`}
                />
                <HistoryStatCard
                  icon={<DamageReportIcon className="text-red-500" size={20} />}
                  label="Damage Reports"
                  value={`${historyData.repairsReported} Repairs Reported`}
                />
                <HistoryStatCard
                  icon={<TypeOwnersIcon className="text-red-500" size={20} />}
                  label="Type of Owner"
                  value={historyData.ownerTypes.join(", ")}
                />
                <HistoryStatCard
                  icon={<OdometerIcon className="text-red-500" size={20} />}
                  label="Last Odometer Reading"
                  value={`${historyData.lastOdometerReading.toLocaleString()} Miles`}
                />
              </div>
            </div>

            {/* Inspection Certification Section */}
            {showInspectionSection && (
              <div className="p-8 mt-8 bg-white rounded-lg">
                <div className="mb-6">
                  <h3 className="mb-2 text-2xl font-bold text-gray-900">
                    Inspected*
                  </h3>
                  <p className="text-sm text-gray-600">
                    Every vehicle is backed by Toyota's commitment to quality
                    and transparency
                  </p>
                </div>

                {/* Inspection Features Grid */}
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <InspectionCard
                    description="Every vehicle undergoes our rigorous 160-point certification process"
                    iconSrc="/images/vdp/inspected_icon.png"
                    photoAlt="Inspected Vehicle - rigorous 160-point certification"
                    photoSrc="/images/vdp/inspected.png"
                    title="Inspected"
                  />
                  <InspectionCard
                    description="Complete vehicle history with no hidden accidents or major repairs"
                    iconSrc="/images/vdp/verified_icon.png"
                    photoAlt="Verified VIN - complete vehicle history check"
                    photoSrc="/images/vdp/verified.png"
                    title={
                      <>
                        Verified VIN
                        <br />& Full History Check
                      </>
                    }
                  />
                  <InspectionCard
                    description="All damage disclosed upfront with detailed condition reports"
                    iconSrc="/images/vdp/guarantee_icon.png"
                    photoAlt="No hidden damage - all damage disclosed upfront"
                    photoSrc="/images/vdp/guarantee.png"
                    title={
                      <>
                        No Hidden
                        <br />
                        Damage Guarantee
                      </>
                    }
                  />
                  <InspectionCard
                    description="Not satisfied? Return or exchange within 7 days, no questions asked"
                    iconSrc="/images/vdp/return_icon.png"
                    photoAlt="7-day return or exchange policy"
                    photoSrc="/images/vdp/return.png"
                    title={
                      <>
                        7-Day Return
                        <br />
                        or Exchange
                      </>
                    }
                  />
                </div>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
