'use client'

import { Button } from '@tfs-ucmp/ui'
import { ChevronLeft, ChevronRight, MapPin } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import type React from 'react'
import { useState } from 'react'
import type { VehicleDetail } from '~/lib/data/vehicle'

interface VehiclePDPProps {
  vehicle: VehicleDetail
}

export const VehiclePDP: React.FC<VehiclePDPProps> = ({ vehicle }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % vehicle.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + vehicle.images.length) % vehicle.images.length)
  }

  return (
    <div className="mx-auto max-w-7xl md:p-4 lg:p-1">
      {/* Breadcrumb Navigation */}
      <div className="flex items-center justify-between px-4 py-3 mb-2 lg:mb-4 lg:px-0 lg:py-4">
        <nav aria-label="Breadcrumb">
          <ol className="flex items-center gap-1 text-sm text-foreground">
            <li>
              <Link className="hover:text-gray-700" href="/used-cars">
                Toyota
              </Link>
            </li>
            <li aria-hidden="true">&gt;</li>
            <li>
              <Link className="hover:text-gray-700" href="/used-cars?make=toyota&model=highlander">
                Highlander
              </Link>
            </li>
            <li aria-hidden="true">&gt;</li>
            <li aria-current="page">XLE</li>
          </ol>
        </nav>
        <div className="flex items-center gap-4">
          <button aria-label="Share this vehicle" className="hover:opacity-70" type="button">
            <Image
              alt=""
              aria-hidden="true"
              className="w-5 h-5"
              height={20}
              src="/images/vdp/Vector_6.svg"
              width={20}
            />
          </button>
          <button aria-label="Save to favorites" className="hover:opacity-70" type="button">
            <Image
              alt=""
              aria-hidden="true"
              className="w-5 h-5"
              height={20}
              src="/images/vdp/Vector_8.svg"
              width={20}
            />
          </button>
          <button aria-label="Print vehicle details" className="hover:opacity-70" type="button">
            <Image
              alt=""
              aria-hidden="true"
              className="w-5 h-5"
              height={20}
              src="/images/vdp/Vector_7.svg"
              width={20}
            />
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row lg:gap-10">
        {/* Left Side - Image Section */}
        <div className="flex flex-col gap-4">
          {/* Main Image Carousel */}
          <div
            aria-label="Vehicle image gallery"
            aria-roledescription="carousel"
            className="relative aspect-[4/3] w-full overflow-hidden rounded-none bg-gray-100 lg:aspect-auto lg:h-[518px] lg:w-[58.89vw] lg:max-w-[848px] lg:rounded-[16px]"
            role="region"
          >
            <Image
              alt={`${vehicle.year} ${vehicle.make} ${vehicle.model} ${vehicle.trim} - Image ${currentImageIndex + 1} of ${vehicle.images.length}`}
              className="object-cover"
              fill
              priority={currentImageIndex === 0}
              sizes="(max-width: 1024px) 100vw, 848px"
              src={vehicle.images[currentImageIndex] as string}
            />

            {/* Navigation Arrows - Desktop only */}
            <button
              aria-label="Previous image"
              className="absolute hidden p-2 -translate-y-1/2 bg-white rounded-full shadow-md top-1/2 left-4 hover:bg-gray-50 lg:flex"
              onClick={prevImage}
              type="button"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              aria-label="Next image"
              className="absolute hidden p-2 -translate-y-1/2 bg-white rounded-full shadow-md top-1/2 right-4 hover:bg-gray-50 lg:flex"
              onClick={nextImage}
              type="button"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Image Count Badge */}
            <div className="absolute flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm right-4 bottom-4">
              <Image
                alt=""
                aria-hidden="true"
                className="w-4 h-4"
                height={16}
                src="/images/vdp/PDP_prev.svg"
                width={16}
              />
              <span className="text-center font-normal text-[12px] text-foreground leading-normal">
                {vehicle.images.length} Images
              </span>
            </div>
            {/* Live region for screen readers */}
            <div aria-atomic="true" aria-live="polite" className="sr-only">
              Showing image {currentImageIndex + 1} of {vehicle.images.length}
            </div>
          </div>

          {/* Thumbnail Gallery */}
          <div className="scrollbar-hide flex gap-2 overflow-x-auto pb-2 pl-[24px] lg:gap-4 lg:pl-0">
            {vehicle.images.map((img, idx) => (
              <button
                aria-label={`View image ${idx + 1} of ${vehicle.images.length}`}
                aria-pressed={idx === currentImageIndex}
                className={`flex-shrink-0 rounded-[16px] border-2 p-1 transition-all ${
                  idx === currentImageIndex
                    ? 'border-red-500'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                key={idx}
                onClick={() => setCurrentImageIndex(idx)}
                type="button"
              >
                <Image
                  alt={`${vehicle.year} ${vehicle.make} ${vehicle.model} ${vehicle.trim} thumbnail ${idx + 1}`}
                  className="object-contain rounded-md"
                  height={72}
                  src={img}
                  width={72}
                />
              </button>
            ))}
          </div>

          {/* Key Highlights - Desktop only */}
          <div className="hidden p-4 bg-gray-100 rounded-lg lg:block">
            <h2 className="mb-4 text-xl font-semibold">Key Highlights</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {vehicle.highlights.map((feature, idx) => (
                <div className="flex items-center gap-2" key={idx}>
                  <Image
                    alt=""
                    aria-hidden="true"
                    className="flex-shrink-0 w-5 h-5"
                    height={20}
                    src="/images/vdp/Vector_5.svg"
                    width={20}
                  />
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side - Details Section */}
        <div className="mt-4 flex w-full flex-col gap-4 px-[24px] lg:mt-0 lg:w-[392px] lg:gap-3 lg:px-0">
          {/* Title and Price */}
          <div>
            <h1 className="mb-2 font-bold text-foreground text-xl leading-tight lg:text-[32px] lg:leading-[42px]">
              {vehicle.year} {vehicle.make} {vehicle.model} {vehicle.trim}
            </h1>
            <div className="flex flex-wrap items-baseline gap-2 lg:gap-3">
              <span className="font-bold text-2xl text-[#EB0A1E] leading-normal lg:text-[32px]">
                ${vehicle.price.toLocaleString()}
              </span>
              <span className="font-normal text-[12px] text-muted-foreground leading-normal line-through lg:text-[14px]">
                was ${vehicle.originalPrice.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap gap-2">
            <div className="inline-flex h-[24px] items-center gap-1.5 rounded-md bg-[#10B981] px-3 py-1.5">
              <Image
                alt=""
                aria-hidden="true"
                className="w-4 h-4"
                height={16}
                src="/images/vdp/Vector_1.svg"
                width={16}
              />
              <span className="text-center font-semibold text-[10px] text-white leading-normal">
                {vehicle.condition}
              </span>
            </div>
            {vehicle.warranty && (
              <div className="inline-flex h-[24px] items-center gap-1.5 rounded-md bg-white px-3 py-1.5 font-medium text-gray-700 text-sm">
                <Image
                  alt=""
                  aria-hidden="true"
                  className="w-4 h-4"
                  height={16}
                  src="/images/vdp/Vector_2.svg"
                  width={16}
                />
                <span className="text-[10px]">Warranty</span>
              </div>
            )}
            {vehicle.inspected && (
              <div className="inline-flex h-[24px] items-center gap-1.5 rounded-md bg-white px-3 py-1.5 font-medium text-gray-700 text-sm">
                <Image
                  alt=""
                  aria-hidden="true"
                  className="w-4 h-4"
                  height={16}
                  src="/images/vdp/Vector_3.svg"
                  width={16}
                />
                <span className="text-[10px]">Inspected</span>
              </div>
            )}
          </div>

          {/* Specs Grid */}
          <div className="py-4 border-t border-gray-200 lg:py-5">
            <div className="grid grid-cols-3 gap-3 pb-4 lg:gap-4">
              <div>
                <p className="font-semibold text-[#111] text-[12px] capitalize opacity-50">Miles</p>
                <p className="mt-1 font-semibold text-[#111] text-[14px] leading-normal">
                  {vehicle.miles}
                </p>
              </div>
              <div>
                <p className="font-semibold text-[#111] text-[12px] capitalize opacity-50">
                  Drivetrain
                </p>
                <p className="mt-1 font-semibold text-[#111] text-[14px] leading-normal">
                  {vehicle.drivetrain}
                </p>
              </div>
              <div>
                <p className="font-semibold text-[#111] text-[12px] capitalize opacity-50">MPG</p>
                <p className="mt-1 font-semibold text-[#111] text-[14px] leading-normal">
                  {vehicle.mpg}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 pt-4 pb-4 border-b border-gray-200 lg:gap-4">
              <div>
                <p className="font-semibold text-[#111] text-[12px] capitalize opacity-50">
                  Stock #
                </p>
                <p className="mt-1 font-semibold text-[#111] text-[14px] leading-normal">
                  {vehicle.stock}
                </p>
              </div>
              <div className="col-span-2">
                <p className="font-semibold text-[#111] text-[12px] capitalize opacity-50">VIN</p>
                <p className="mt-1 font-semibold text-[#111] text-[14px] leading-normal">
                  {vehicle.vin}
                </p>
              </div>
            </div>
          </div>

          {/* Colors */}
          <div className="flex gap-8 pb-4 border-b border-gray-200 lg:gap-12">
            <div className="flex items-start gap-2">
              <div
                className="mt-[4.5%] h-[28px] w-[28px] rounded-[2px]"
                style={{
                  background: 'linear-gradient(166deg, #3F3F3F -30%, #A5A5A5 140%)',
                }}
              />
              <div className="flex flex-col">
                <p className="font-semibold text-[#111] text-[12px] capitalize opacity-50">
                  Exterior
                </p>
                <span className="font-semibold text-[#111] text-[14px] leading-normal">
                  {vehicle.exteriorColor}
                </span>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="mt-[4.5%] h-[28px] w-[28px] rounded-[2px] bg-black" />
              <div className="flex flex-col">
                <p className="font-semibold text-[#111] text-[12px] capitalize opacity-50">
                  Interior
                </p>
                <span className="font-semibold text-[#111] text-[14px] leading-normal">
                  {vehicle.interiorColor}
                </span>
              </div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col gap-3">
            <Button className="w-full rounded-[100px] bg-[#EB0A1E] py-4 text-center font-semibold text-[14px] text-white hover:bg-red-700 lg:py-6">
              Get Pre-Qualified
            </Button>
            <Button
              className="w-full rounded-[100px] border border-[#58595B] bg-white py-4 text-center font-semibold text-[#111] text-[14px] hover:bg-gray-50 lg:py-6"
              variant="outline"
            >
              Get My Trade-In Offer
            </Button>
          </div>

          {/* Dealer Info */}
          <div className="py-4 border-t border-b border-gray-200">
            <div className="flex items-end justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-[32px] w-[32px] items-center justify-center rounded-full bg-[#EB0A1E]">
                  <Image
                    alt="Toyota"
                    className="h-[24px] w-[23px]"
                    height={24}
                    src="/images/vdp/Vector_4.svg"
                    width={23}
                  />
                </div>
                <div>
                  <p className="font-semibold text-[#272727] text-[14px] leading-[130%] tracking-[-0.42px]">
                    {vehicle.dealer.name}
                  </p>
                  <p className="font-normal text-[#58595B] text-[12px] leading-normal">
                    {vehicle.dealer.location}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 font-normal text-[#58595B] text-[12px] leading-normal">
                <MapPin className="h-3.5 w-3.5" />
                <span>{vehicle.dealer.distance}</span>
              </div>
            </div>
          </div>

          {/* Key Highlights - Mobile only */}
          <div className="p-4 bg-gray-100 rounded-lg lg:hidden">
            <h2 className="mb-4 text-lg font-semibold">Key Highlights</h2>
            <div className="grid grid-cols-1 gap-3">
              {vehicle.highlights.map((feature, idx) => (
                <div className="flex items-center gap-2" key={idx}>
                  <Image
                    alt=""
                    aria-hidden="true"
                    className="flex-shrink-0 w-4 h-4"
                    height={16}
                    src="/images/vdp/Vector_5.svg"
                    width={16}
                  />
                  <span className="text-xs">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
