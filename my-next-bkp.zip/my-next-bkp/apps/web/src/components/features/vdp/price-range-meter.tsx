"use client";

import { cn } from "@tfs-ucmp/ui";
import { getPriceCategory } from "~/lib/formatters";

interface PriceRangeMeterProps {
  currentPrice: number;
  avgPrice: number;
}

/**
 * PriceRangeMeter - Visualizes where a vehicle's price falls relative to market average.
 * Renders a segmented bar (Excellent → Good → Fair → High) with price markers.
 */
export function PriceRangeMeter({
  currentPrice,
  avgPrice,
}: PriceRangeMeterProps) {
  // Calculate percentage position for current price (0-100%)
  // Range: 0.7 * avgPrice to 1.3 * avgPrice
  const minPrice = avgPrice * 0.7;
  const maxPrice = avgPrice * 1.3;
  const currentPercentage = Math.min(
    100,
    Math.max(0, ((currentPrice - minPrice) / (maxPrice - minPrice)) * 100),
  );

  // Calculate percentage for avg price marker (should be around 50%)
  const avgPercentage = 50;

  // Determine price category based on where the price falls
  const { color: categoryColor } = getPriceCategory(currentPercentage);

  // Bar segment percentages - 4 equal segments
  const excellentEnd = 25;
  const goodEnd = 50;
  const fairEnd = 75;
  // High: 75-100

  return (
    <div className="w-full">
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1" />
        <div className="flex flex-col items-center" style={{ minWidth: 100 }}>
          <div
            className={cn(
              "mb-1 whitespace-nowrap rounded-full px-4 py-1 font-bold text-lg text-white",
              categoryColor,
            )}
          >
            ${currentPrice.toLocaleString()}
          </div>
        </div>
        <div className="flex justify-end flex-1">
          <div className="text-right">
            <div className="text-lg font-bold text-gray-900">
              ${avgPrice.toLocaleString()}
            </div>
            <div className="text-xs text-gray-600">Avg. market price (IMV)</div>
          </div>
        </div>
      </div>
      {/* Segmented bar with markers - 4 segments */}
      <div
        className="relative flex items-center w-full mb-2"
        style={{ height: 32 }}
      >
        {/* Segments */}
        <div className="absolute top-1/2 left-0 z-0 flex h-2.5 w-full -translate-y-1/2 gap-1.5">
          <div
            className="h-2.5 rounded-full bg-green-500"
            style={{ width: `${excellentEnd}%` }}
          />
          <div
            className="h-2.5 rounded-full bg-green-700"
            style={{ width: `${goodEnd - excellentEnd}%` }}
          />
          <div
            className="h-2.5 rounded-full bg-gray-700"
            style={{ width: `${fairEnd - goodEnd}%` }}
          />
          <div
            className="h-2.5 rounded-full bg-orange-500"
            style={{ width: `${100 - fairEnd}%` }}
          />
        </div>
        {/* Current price marker */}
        <div
          className="absolute z-10 -translate-y-1/2 top-1/2"
          style={{ left: `calc(${currentPercentage}% - 8px)` }}
        >
          <div
            className={cn(
              "h-4 w-4 rounded-full border-2 border-white shadow-lg",
              categoryColor,
            )}
          />
        </div>
        {/* Avg price marker */}
        <div
          className="absolute z-10 -translate-y-1/2 top-1/2"
          style={{ left: `calc(${avgPercentage}% - 8px)` }}
        >
          <div className="w-4 h-4 bg-gray-900 border-2 border-white rounded-full shadow-lg" />
        </div>
      </div>
      {/* Labels below bar */}
      <div className="flex justify-between w-full text-xs text-center">
        <div className="flex-1 font-medium text-gray-900">Excellent</div>
        <div className="flex-1 font-medium text-gray-900">Good</div>
        <div className="flex-1 font-medium text-gray-900">Fair</div>
        <div className="flex-1 font-medium text-gray-900">High</div>
      </div>
    </div>
  );
}
