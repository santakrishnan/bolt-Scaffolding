import type { ReactNode } from "react";

interface HistoryStatCardProps {
  icon: ReactNode;
  label: string;
  value: string;
}

/**
 * HistoryStatCard - Reusable card for displaying a single vehicle history stat.
 * Used in the History tab grid (e.g. "No Damage", "Previous Owners", etc.).
 */
export function HistoryStatCard({ icon, label, value }: HistoryStatCardProps) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center justify-center flex-shrink-0 w-10 h-10 rounded-lg bg-red-50">
        {icon}
      </div>
      <div>
        <h4 className="mb-0.5 text-gray-600 text-xs">{label}</h4>
        <p className="text-base font-bold text-gray-900">{value}</p>
      </div>
    </div>
  );
}
