'use client'

import React, { useState, useRef } from 'react'
import {
      Dialog,
      DialogContent,
      DialogTrigger,
      Button,
} from '@tfs-ucmp/ui'
import { ChevronLeft, ChevronRight, Share2, Heart, Printer, X, MapPin, ArrowLeft, Check } from 'lucide-react'
import { getTestImages } from './get-test-images'

export const VehiclePreviewModal: React.FC = () => {
      const [open, setOpen] = useState(false)
      const [currentImageIndex, setCurrentImageIndex] = useState(0)
      const [isDragging, setIsDragging] = useState(false)
      const [dragStart, setDragStart] = useState(0)
      const [scrollLeft, setScrollLeft] = useState(0)
      const [featuresExpanded, setFeaturesExpanded] = useState(false)
      const galleryRef = useRef<HTMLDivElement>(null)

      // Demo vehicle data
      const vehicle = {
            year: 2023,
            make: 'Toyota',
            model: 'Highlander XLE',
            price: 43098,
            originalPrice: 35900,
            condition: 'Excellent Price',
            warranty: true,
            inspected: true,
            miles: '18,450',
            drivetrain: 'AWD',
            mpg: '18-24',
            stock: '990167H',
            vin: '2T3P1RF5VNW123456',
            exterior: 'Graphite Fabric',
            interior: 'Charcoal Gray',
            dealer: 'Toyota of Fort Worth',
            location: 'Fort Worth, TX 76116',
            distance: '6.1mi',
            images: getTestImages(),
            features: [
                  'Apple CarPlay/Android Auto',
                  'Around View Camera',
                  'Pedestrian Detection',
                  'Bluetooth Hands-Free/ Streaming Audio',
                  'Forward Collision Warning',
                  'Voice Command',
                  'Rear Sunshade',
                  'Power Trunk/ Liftgate',
                  'LED Highlights',
                  'Folding Mirrors',
                  'Blind Spot Monitor',
                  'Lane Departure Warning',
                  'Adaptive Cruise Control',
                  'Heated Seats',
                  'Ventilated Seats',
                  'Panoramic Sunroof',
                  'Navigation System',
                  'Premium Sound System',
            ],
      }

      const nextImage = () => {
            setCurrentImageIndex((prev) => (prev + 1) % vehicle.images.length)
      }

      const prevImage = () => {
            setCurrentImageIndex((prev) => (prev - 1 + vehicle.images.length) % vehicle.images.length)
      }

      // Dragging handlers
      const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
            setIsDragging(true)
            setDragStart(e.pageX - (galleryRef.current?.offsetLeft || 0))
            setScrollLeft(galleryRef.current?.scrollLeft || 0)
      }

      const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
            if (!isDragging || !galleryRef.current) return
            e.preventDefault()
            const x = e.pageX - (galleryRef.current?.offsetLeft || 0)
            const walk = (x - dragStart) * 0.5
            galleryRef.current.scrollLeft = scrollLeft - walk
      }

      const handleMouseUp = () => {
            setIsDragging(false)
      }

      return (
            <Dialog open={open} onOpenChange={setOpen}>
                  <DialogTrigger asChild>
                        <Button>View Vehicle</Button>
                  </DialogTrigger>
                  <DialogContent
                        className="p-0 md:!top-[7.5vh] !top-0 !-translate-x-1/2 !translate-y-0 w-full md:w-[94vw] max-w-[1400px] h-full md:h-[85vh] !rounded-none md:!rounded-lg"
                  >
                        <div className="flex flex-col h-full overflow-hidden bg-white md:rounded-lg">
                              {/* Mobile Header - Back to Search */}
                              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 md:hidden">
                                    <button
                                          onClick={() => setOpen(false)}
                                          className="flex items-center gap-2 text-sm font-medium text-black hover:opacity-70"
                                    >
                                          <ArrowLeft className="w-5 h-5" />
                                          <span>Back to Search</span>
                                    </button>
                                    <div className="flex items-center gap-4">
                                          <button className="hover:opacity-70">
                                                <Share2 className="w-5 h-5" />
                                          </button>
                                          <button className="hover:opacity-70">
                                                <Heart className="w-5 h-5" />
                                          </button>
                                          <button className="hover:opacity-70">
                                                <Printer className="w-5 h-5" />
                                          </button>
                                    </div>
                              </div>

                              {/* Desktop Header - Vehicle Preview */}
                              <div className="items-center justify-between hidden px-6 py-4 md:flex">
                                    <span className="text-[16px] font-normal leading-[20px] text-black">Vehicle Preview</span>
                                    <div className="flex items-center gap-4">
                                          <button className="hover:opacity-70">
                                                <Share2 className="w-6 h-6" />
                                          </button>
                                          <button className="hover:opacity-70">
                                                <Heart className="w-6 h-6" />
                                          </button>
                                          <button className="hover:opacity-70">
                                                <Printer className="w-6 h-6" />
                                          </button>
                                          <button onClick={() => setOpen(false)} className="hover:opacity-70">
                                                <X className="w-6 h-6" />
                                          </button>
                                    </div>
                              </div>

                              {/* Main Content - Image and Details */}
                              <div className="flex flex-col flex-1 min-h-0 overflow-hidden md:flex-row">
                                    {/* Left Side - Image Section (65% on desktop) */}
                                    <div className="flex flex-col gap-3 md:gap-4 md:pr-[45px] md:pl-[54px] md:pt-0 md:pr-6 md:w-[65%] md:flex-shrink-0 overflow-y-auto md:overflow-visible">
                                          {/* Main Image */}
                                          <div className="relative w-full h-[240px] sm:h-[300px] md:h-[80%] overflow-hidden md:rounded-[16px] bg-gray-100">
                                                <img
                                                      src={vehicle.images[currentImageIndex]}
                                                      alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                                                      className="object-contain w-full h-full"
                                                />

                                                {/* Navigation Arrows - Hidden on mobile */}
                                                <button
                                                      onClick={prevImage}
                                                      className="absolute hidden p-2 -translate-y-1/2 bg-white rounded-full shadow-md md:block left-4 top-1/2 hover:bg-gray-50"
                                                      aria-label="Previous image"
                                                >
                                                      <ChevronLeft className="w-6 h-6" />
                                                </button>
                                                <button
                                                      onClick={nextImage}
                                                      className="absolute hidden p-2 -translate-y-1/2 bg-white rounded-full shadow-md md:block right-4 top-1/2 hover:bg-gray-50"
                                                      aria-label="Next image"
                                                >
                                                      <ChevronRight className="w-6 h-6" />
                                                </button>

                                                {/* Image Count Badge */}
                                                <div className="absolute bottom-3 md:bottom-4 right-3 md:right-4 flex items-center gap-1.5 md:gap-2 rounded-full bg-white px-3 md:px-4 py-1.5 md:py-2 shadow-sm">
                                                      <img src="/assets/images/vdp/Image-count.svg" alt="" className="h-3.5 w-3.5 md:h-4 md:w-4" />
                                                      <span className="text-[11px] md:text-[12px] font-normal leading-normal text-[#111] text-center">{vehicle.images.length} Images</span>
                                                </div>
                                          </div>

                                          {/* Thumbnail Gallery */}
                                          <div className="flex gap-2 px-4 pb-2 overflow-x-auto md:gap-3 scrollbar-hide md:px-0 md:pr-6 ">
                                                {vehicle.images.map((img, idx) => (
                                                      <button
                                                            key={idx}
                                                            onClick={() => setCurrentImageIndex(idx)}
                                                            className={`flex-shrink-0 rounded-[6px] md:rounded-[8px] overflow-hidden transition-all border-2 ${idx === currentImageIndex
                                                                  ? 'border-red-500'
                                                                  : 'border-gray-200 hover:border-gray-300'
                                                                  }`}
                                                      >
                                                            <img src={img} alt={`Thumbnail ${idx + 1}`} className="h-[98px] w-[98px] md:h-[107px] md:w-[107px] object-cover" />
                                                      </button>
                                                ))}
                                          </div>
                                    </div>

                                    {/* Right Side - Details (35% on desktop) */}
                                    <div className="flex flex-col md:w-[35%] bg-white overflow-hidden min-h-0">
                                          {/* Scrollable Content Area */}
                                          <div className="flex-1 min-h-0 px-4 pb-4 overflow-y-auto md:pb-0 scrollbar-hide">

                                                {/* Title and Price */}
                                                <div className="mb-3 md:mb-4">
                                                      <h1 className="text-[22px] md:text-[32px] font-bold leading-tight">
                                                            <span className="md:hidden">{vehicle.year} {vehicle.make} {vehicle.model}</span>
                                                            <span className="hidden md:inline">{vehicle.year} {vehicle.make} <br /> {vehicle.model}</span>
                                                      </h1>
                                                      <div className="flex items-baseline gap-2 mt-1">
                                                            <span
                                                                  className="text-[22px] md:text-[32px] font-bold text-[#EB0A1E] leading-normal"
                                                                  style={{ fontFamily: '"Toyota Type Bold", sans-serif' }}
                                                            >
                                                                  ${vehicle.price.toLocaleString()}
                                                            </span>
                                                            <span className="text-sm text-gray-500 md:text-base">was</span>
                                                            <span className="text-sm text-gray-500 line-through md:text-base">${vehicle.originalPrice.toLocaleString()}</span>
                                                      </div>
                                                </div>

                                                {/* Badges */}
                                                <div className="mb-4 md:mb-[16px] flex flex-wrap gap-2">
                                                      <div className="inline-flex items-center gap-1.5 rounded-md bg-[#10B981] px-2.5 md:px-3 py-1 md:py-1.5 h-[22px] md:h-[24px]">
                                                            <img src="/assets/images/vdp/Excellent-price.svg" alt="" className="h-3.5 w-3.5 md:h-4 md:w-4" />
                                                            <span className="text-center text-[10px] font-semibold leading-normal text-white">{vehicle.condition}</span>
                                                      </div>
                                                      {vehicle.warranty && (
                                                            <div className="inline-flex items-center gap-1.5 rounded-md bg-white border border-gray-200 px-2.5 md:px-3 py-1 md:py-1.5 h-[22px] md:h-[24px] text-sm font-medium text-gray-700">
                                                                  <img src="/assets/images/vdp/Warranty.svg" alt="" className="h-3.5 w-3.5 md:h-4 md:w-4" />
                                                                  <span className="text-[10px]">Warranty</span>
                                                            </div>
                                                      )}
                                                      {vehicle.inspected && (
                                                            <div className="inline-flex items-center gap-1.5 rounded-md bg-white border border-gray-200 px-2.5 md:px-3 py-1 md:py-1.5 h-[22px] md:h-[24px] text-sm font-medium text-gray-700">
                                                                  <img src="/assets/images/vdp/Inspected.svg" alt="" className="h-3.5 w-3.5 md:h-4 md:w-4" />
                                                                  <span className="text-[10px]">Inspected</span>
                                                            </div>
                                                      )}
                                                </div>

                                                {/* Specs Grid */}
                                                <div className="mb-4 md:mb-[17.5px] grid grid-cols-3 md:grid-cols-3 gap-3 md:gap-4 border-y py-3 md:py-4">
                                                      <div>
                                                            <p className="text-[10px] md:text-xs text-gray-500">Miles</p>
                                                            <p className="text-sm font-semibold md:text-base">{vehicle.miles}</p>
                                                      </div>
                                                      <div>
                                                            <p className="text-[10px] md:text-xs text-gray-500">Drivetrain</p>
                                                            <p className="text-sm font-semibold md:text-base">{vehicle.drivetrain}</p>
                                                      </div>
                                                      <div>
                                                            <p className="text-[10px] md:text-xs text-gray-500">MPG</p>
                                                            <p className="text-sm font-semibold md:text-base">{vehicle.mpg}</p>
                                                      </div>
                                                      <div>
                                                            <p className="text-[10px] md:text-xs text-gray-500">Stock #</p>
                                                            <p className="text-sm font-semibold md:text-base">{vehicle.stock}</p>
                                                      </div>
                                                      <div className="col-span-2">
                                                            <p className="text-[10px] md:text-xs text-gray-500">VIN</p>
                                                            <p className="text-sm font-semibold md:text-base">{vehicle.vin}</p>
                                                      </div>
                                                </div>

                                                {/* Colors */}
                                                <div className="flex gap-6 pb-4 border-b border-gray-200 md:gap-8 lg:gap-12">
                                                      <div className="flex items-start gap-2">
                                                            <div className="h-[24px] w-[24px] md:h-[28px] md:w-[28px] rounded-[2px] mt-[4.5%]" style={{ background: 'linear-gradient(166deg, #3F3F3F -30%, #A5A5A5 140%)' }} />
                                                            <div className="flex flex-col">
                                                                  <p className="text-[10px] md:text-[12px] font-semibold text-[#111] capitalize opacity-50">Exterior</p>
                                                                  <span className="text-[12px] md:text-[14px] font-semibold text-[#111] leading-normal">{vehicle.exterior}</span>
                                                            </div>
                                                      </div>
                                                      <div className="flex items-start gap-2">
                                                            <div className="h-[24px] w-[24px] md:h-[28px] md:w-[28px] rounded-[2px] bg-black mt-[4.5%]" />
                                                            <div className="flex flex-col">
                                                                  <p className="text-[10px] md:text-[12px] font-semibold text-[#111] capitalize opacity-50">Interior</p>
                                                                  <span className="text-[12px] md:text-[14px] font-semibold text-[#111] leading-normal">{vehicle.interior}</span>
                                                            </div>
                                                      </div>
                                                </div>

                                                {/* Mobile CTA Buttons */}
                                                <div className="flex flex-col gap-3 py-4 md:hidden">
                                                      <Button className="flex h-11 w-full items-center justify-center gap-2.5 rounded-full bg-[#EB0A1E] px-8 py-2.5 hover:bg-red-700 text-white font-semibold">
                                                            Get Pre-Qualified
                                                      </Button>
                                                      <Button
                                                            variant="outline"
                                                            className="flex h-11 w-full items-center justify-center gap-2.5 rounded-full border-2 border-gray-900 bg-white px-8 py-2.5 hover:bg-gray-50 text-gray-900 font-semibold"
                                                      >
                                                            Get My Trade-In Offer
                                                      </Button>
                                                </div>

                                                {/* Dealer Info */}
                                                <div className="py-4 border-t border-b border-gray-200">
                                                      <div className="flex items-end justify-between">
                                                            <div className="flex items-center gap-2 md:gap-3">
                                                                  <div className="flex h-[28px] w-[28px] md:h-[32px] md:w-[32px] items-center justify-center rounded-full bg-[#EB0A1E]">
                                                                        <img src="/assets/images/vdp/Toyota-logo.svg" alt="Toyota" className="h-[20px] w-[19px] md:h-[24px] md:w-[23px]" />
                                                                  </div>
                                                                  <div>
                                                                        <p className="text-[13px] md:text-[14px] font-semibold text-[#272727] leading-[130%] tracking-[-0.42px]">{vehicle.dealer}</p>
                                                                        <p className="text-[11px] md:text-[12px] font-normal text-[#58595B] leading-normal">{vehicle.location}</p>
                                                                  </div>
                                                            </div>
                                                            <div className="flex items-center gap-1 text-[11px] md:text-[12px] font-normal text-[#58595B] leading-normal">
                                                                  <MapPin className="h-3 w-3 md:h-3.5 md:w-3.5" />
                                                                  <span>{vehicle.distance}</span>
                                                            </div>
                                                      </div>
                                                </div>

                                                {/* Key Features / Key Highlights */}
                                                <div className="pt-4 md:pt-5">
                                                      <div className="mb-3 md:mb-[17.5px] flex items-center justify-between">
                                                            <h3
                                                                  className="text-[14px] md:text-[16px] font-semibold leading-[22px] text-[#111]"
                                                                  style={{ fontFamily: '"Toyota Type Semibold", sans-serif' }}
                                                            >
                                                                  <span className="md:hidden">Key Highlights</span>
                                                                  <span className="hidden md:inline">Key Features</span>
                                                            </h3>
                                                            <button
                                                                  onClick={() => setFeaturesExpanded(!featuresExpanded)}
                                                                  className="flex items-center gap-1 text-[12px] font-semibold leading-[14px] text-black hover:text-gray-800"
                                                                  style={{ fontFamily: '"Toyota Type Semibold", sans-serif' }}
                                                            >
                                                                  {featuresExpanded ? 'Collapse' : 'Expand All'}
                                                                  <ChevronRight className={`h-3 w-3 transition-transform duration-200 ${featuresExpanded ? '-rotate-90' : 'rotate-90'}`} />
                                                            </button>
                                                      </div>
                                                      {/* Mobile: Single column list with check icons */}
                                                      <div className="flex flex-col gap-3 md:hidden">
                                                            {(featuresExpanded ? vehicle.features : vehicle.features.slice(0, 6)).map((feature, idx) => (
                                                                  <div key={idx} className="flex items-center gap-3">
                                                                        <div className="flex items-center justify-center flex-shrink-0 w-5 h-5 border border-gray-300 rounded-full">
                                                                              <Check className="w-3 h-3 text-gray-600" />
                                                                        </div>
                                                                        <span className="text-[13px] text-gray-800">{feature}</span>
                                                                  </div>
                                                            ))}
                                                      </div>
                                                      {/* Desktop: Two column grid */}
                                                      <div className="hidden grid-cols-2 md:grid gap-x-4 gap-y-2">
                                                            {(featuresExpanded ? vehicle.features : vehicle.features.slice(0, 6)).map((feature, idx) => (
                                                                  <div key={idx} className="flex items-center gap-2">
                                                                        <img
                                                                              src="/assets/images/vdp/Keyfeature.svg"
                                                                              alt=""
                                                                              className="h-3.5 w-3.5 flex-shrink-0"
                                                                        />
                                                                        <span className="text-sm">{feature}</span>
                                                                  </div>
                                                            ))}
                                                      </div>
                                                </div>
                                          </div>

                                          {/* Desktop Full Details Button - Fixed at bottom */}
                                          <div className="flex-shrink-0 hidden px-6 py-4 bg-white border-t border-gray-100 md:block">
                                                <Button className="flex h-10 w-full items-center justify-center gap-2.5 rounded-full bg-[#EB0A1E] px-8 py-2.5 hover:bg-red-700">
                                                      Full Details
                                                </Button>
                                          </div>
                                    </div>
                              </div>
                        </div>
                  </DialogContent>
            </Dialog>
      )
}
