// Get images from vdp-images folder
export const getTestImages = (): string[] => {
  return [
    '/assets/images/vdp-images/image 904.png',
    '/assets/images/vdp-images/image 905.png',
    '/assets/images/vdp-images/image 907.png',
    '/assets/images/vdp-images/image 908.png',
    '/assets/images/vdp-images/image 909.png',
    '/assets/images/vdp-images/image 910.png',
    '/assets/images/vdp-images/image 943.png',
  ]
}
