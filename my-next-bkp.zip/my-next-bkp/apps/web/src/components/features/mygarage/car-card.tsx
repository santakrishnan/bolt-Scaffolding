
import React, { useState } from 'react';
import Image from 'next/image';
// Inline SVGs for Heart, Share, and Location
import { StaticImageData } from 'next/image';

export type CarCardProps = {
    title: string;
    price: number;
    image: StaticImageData | string;
    miles: string;
    odometer: string;
    match: number;
    labels?: string[]; // e.g. ["Excellent Price", "Price Drop", "Good Price", "Low Price"]
    oldPrice?: number | null;
    isFavorite?: boolean;
    onFavoriteToggle?: () => void;
};

export const CarCard: React.FC<CarCardProps> = ({
    title,
    price,
    image,
    miles,
    odometer,
    match,
    labels = [],
    oldPrice,
    isFavorite = false,
    onFavoriteToggle,
}) => {
    // Helper for badge color
    const getBadgeColor = (label: string) => {
        switch (label) {
            case "Excellent Price": return "bg-green-500 text-white";
            case "Price Drop": return "bg-blue-500 text-white";
            case "Good Price": return "bg-emerald-400 text-white";
            case "Low Price": return "bg-yellow-400 text-black";
            default: return "bg-gray-200 text-gray-700";
        }
    };
    return (
        <div className="bg-white rounded-lg w-full max-w-xs sm:max-w-sm md:max-w-md flex flex-col relative  min-h-[340px] md:min-h-[380px] p-3">
            {/* Price badges */}
            <div className="absolute z-10 flex flex-col gap-3 top-3 left-3">
                {labels.map((label, idx) => (
                    <span key={idx} className={`text-xs font-semibold px-2 py-1 rounded ${getBadgeColor(label)}`}>{label}</span>
                ))}
            </div>
            {/* Heart and Share icons */}
            <div className="absolute flex gap-3 top-3 right-3">
                <button className="text-gray-400" aria-label="Share">
                    <picture>
                        <source srcSet="/images/garage/share.svg" type="image/svg+xml" />
                        <img src="/images/garage/share.svg" alt="Share" width={22} height={22} />
                    </picture>
                </button>
                <button
                    className={isFavorite ? "text-red-500" : "text-gray-400"}
                    aria-label="Favorite"
                    onClick={onFavoriteToggle}
                >
                    <picture>
                        <source srcSet="/images/garage/heart.svg" type="image/svg+xml" />
                        <img src="/images/garage/heart.svg" alt="Favorite" width={24} height={24} />
                    </picture>
                </button>

            </div>
            <div className="flex justify-center mt-3 mb-3">
                <Image
                    src={typeof image === 'string' && image.startsWith('/images/') ? image : (image as string)}
                    alt={title}
                    width={220}
                    height={120}
                    className="object-contain w-auto max-w-full h-28 sm:h-32 md:h-40"
                    unoptimized
                />
            </div>
            <div className="mb-3 border-t border-gray-200" />
            <div className='flex flex-col gap-y-3'>
                <div className=''>
                    <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
                        <div
                            className="font-toyota font-bold text-[16px] leading-[1.3] text-[#111] "
                        >
                            {title}
                        </div>
                        <div className="flex flex-col items-end">
                            {oldPrice && (
                                <span className="text-xs text-gray-400 line-through">${oldPrice.toLocaleString()}</span>
                            )}
                            <span
                                className="font-toyota font-semibold text-[20px] text-[#EB0D1C] text-right leading-normal"
                            >
                                ${price.toLocaleString()}
                            </span>
                        </div>
                    </div>
                    <div className="flex flex-wrap items-center justify-between gap-3 mt-3 text-xs text-gray-500">
                        <div>
                            <picture>
                                <source srcSet="/images/garage/location.svg" type="image/svg+xml" />
                                <img src="/images/garage/location.svg" alt="Location" width={16} height={16} className="inline w-4 h-4 mr-1" />
                            </picture>
                            <span>{miles}</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <picture>
                                <source media="(min-width: 768px)" srcSet="/images/garage/odometer.svg" />
                                <img
                                    src="/images/garage/odometer.svg"
                                    alt="Odometer"
                                    width={15}
                                    height={15}
                                    className="inline"
                                />
                            </picture>
                            <span>{odometer}</span>
                        </div>

                    </div>
                </div>
                <div className="border-t border-gray-200" />
                <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="px-2 py-1 text-xs font-semibold text-white bg-black rounded">{match}% Match</span>
                    <a href="#" className="ml-auto text-xs text-gray-600 underline">Refine your search</a>
                </div>
                <div className="border-t border-gray-200" />
                <div className="flex flex-wrap justify-between gap-3 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                        <picture>
                            <source media="(min-width: 768px)" srcSet="/images/garage/warranty.svg" />
                            <img
                                src="/images/garage/warranty.svg"
                                alt="Warranty"
                                width={12}
                                height={16}
                                className="inline"
                            />
                        </picture>
                        Warranty
                    </span>
                    <span className="flex items-center gap-1">
                        <picture>
                            <source media="(min-width: 768px)" srcSet="/images/garage/inspected.svg" />
                            <img
                                src="/images/garage/inspected.svg"
                                alt="Inspected"
                                width={15}
                                height={15}
                                className="inline"
                            />
                        </picture>
                        Inspected
                    </span>
                    <span className="flex items-center gap-1">
                        <picture>
                            <source media="(min-width: 768px)" srcSet="/images/garage/p.svg" />
                            <img
                                src="/images/garage/p.svg"
                                alt="1 Owner"
                                width={12}
                                height={16}
                                className="inline"
                            />
                        </picture>
                        1 Owner
                    </span>
                </div>
            </div>
        </div>
    );
};
