import React from "react";

export type VehicleStatCardProps = {
    icon: React.ReactNode;
    title: string;
    count: string;
    countColor?: string;
    subtitle?: string;
    onClick?: () => void;
};

export const VehicleStatCard: React.FC<VehicleStatCardProps> = ({
    icon,
    title,
    count,
    countColor = "text-[#E53935]",
    subtitle = "vehicles",
    onClick,
}) => (
    <div
        className="flex flex-col items-center justify-center bg-white rounded-lg border border-[#E6E6E6] shadow-sm w-[308px] px-[56px] py-[32px] cursor-pointer transition-shadow hover:shadow-md min-h-[140px]"
        onClick={onClick}
    >
        <div className="mb-3">{icon}</div>
        <div className="mb-1 text-base font-semibold text-center">{title}</div>
        <div className={`font-bold text-sm ${countColor}`}>{count} <span className="font-normal text-gray-500">{subtitle}</span></div>
    </div>
);


export type VehicleStatsGridProps = {
    cards: VehicleStatCardProps[];
    title?: string;
};

export const VehicleStatsGrid: React.FC<VehicleStatsGridProps> = ({ cards, title = "Find your vehicle" }) => (
    <section className="flex flex-col items-center w-full px-2 py-8">
        <h2 className="mb-6 text-2xl font-semibold text-center">{title}</h2>
        <div className="flex flex-row justify-center w-full max-w-6xl gap-4">
            {cards.map((card: VehicleStatCardProps, idx: number) => (
                <VehicleStatCard key={idx} {...card} />
            ))}
        </div>
    </section>
);
