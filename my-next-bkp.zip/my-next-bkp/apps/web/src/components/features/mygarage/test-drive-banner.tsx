import React from "react";
import Image from "next/image";

export type TestDriveBannerProps = {
    title?: string;
    description?: string;
    buttonText?: string;
    onButtonClick?: () => void;
    imageUrl?: string;
    imageAlt?: string;
};

export const TestDriveBanner: React.FC<TestDriveBannerProps> = ({
    title = "SCHEDULE A TEST DRIVE",
    description =
    "Book a test drive at a time that works for you. Choose your preferred model and we'll have it ready when you arrive.",
    buttonText = "Book Your Test Drive",
    onButtonClick,
    imageUrl = "/images/vehicles/yaris-cross.png",
    imageAlt = "Car rear view for test drive banner",
}) => {
    return (
        <section className="relative flex flex-col items-stretch w-full overflow-hidden bg-black shadow-lg md:flex-row">
            <div className="flex-1 flex flex-col justify-center px-8 py-8 md:py-0 bg-black/80 z-10 md:max-w-[40%]">
                <h2 className="mb-3 text-2xl font-bold text-white md:text-3xl">{title}</h2>
                <p className="max-w-xs mb-5 text-sm text-white md:text-base">{description}</p>
                <button
                    className="bg-[#E53935] hover:bg-[#c62828] text-white font-semibold px-5 py-2 rounded-full text-sm transition-colors duration-200 w-fit"
                    onClick={onButtonClick}
                >
                    {buttonText}
                </button>
            </div>
            <div className="flex-1 relative min-w-[200px]" style={{ width: '100%', aspectRatio: '3/2' }}>
                <Image
                    src={imageUrl}
                    alt={imageAlt}
                    width={951}
                    height={760}
                    style={{ aspectRatio: '234/187', width: '100%', height: '100%' }}
                    className="absolute top-0 left-0 object-cover"
                    draggable={false}
                    onError={(e) => {
                        // fallback to a placeholder if image fails to load
                        (e.target as HTMLImageElement).src = "/images/vehicles/yaris-cross.png";
                    }}
                />
                <div className="absolute inset-0 pointer-events-none bg-gradient-to-l from-black/80 to-transparent md:from-black/0 md:to-black/80" style={{ width: '100%', height: '100%' }} />
            </div>
        </section>
    );
};
