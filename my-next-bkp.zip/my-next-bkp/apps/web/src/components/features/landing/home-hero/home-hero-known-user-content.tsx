'use client'

import * as React from 'react'
import Image from 'next/image'
import { Button } from 'ui/primitives/button'
import { Card } from 'ui/primitives/card'
import { Carousel, CarouselContent, CarouselItem, CarouselDots } from 'ui/primitives/carousel'
import { cn } from 'ui/lib/utils'
import { CheckCircleIcon, CalendarIcon, LocationPinIcon, ClockIcon } from 'ui/assets/icons'

export interface SavedVehicle {
  year: number
  make: string
  model: string
  price: number
  image?: string
  vin?: string
  mileage?: number
  stockNumber?: string
}

export interface TradeInOffer {
  year: number
  make: string
  model: string
  offerAmount: number
  expiresInDays: number
}

export interface HomeHeroKnownUserContentProps {
  userName: string
  isPreQualified?: boolean
  savedVehicle?: SavedVehicle
  preQualifiedVehicle?: SavedVehicle
  tradeInOffer?: TradeInOffer
  onBuyOnline?: () => void
  onScheduleTestDrive?: () => void
  onAcceptOffer?: () => void
  onContinueShopping?: () => void
}

export function HomeHeroKnownUserContent({
  userName,
  isPreQualified = false,
  savedVehicle,
  preQualifiedVehicle,
  tradeInOffer,
  onBuyOnline,
  onScheduleTestDrive,
  onAcceptOffer,
  onContinueShopping,
}: HomeHeroKnownUserContentProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(price)
  }

  return (
    <div className="w-full flex justify-center pt-16 sm:pt-20 lg:pt-24">
      <div className="w-full max-w-[1440px] flex flex-col items-start">
        {/* Personalized Title */}
        <div className="space-y-1 md:space-y-2">
          <h1 className="w-full max-w-[715px] text-[20px] sm:text-[28px] md:text-[36px] lg:text-[40px] font-bold uppercase leading-[1.2] md:leading-[44px] tracking-[-0.449px] text-white">
            WELCOME BACK, {userName.toUpperCase()}!
          </h1>
          <p className="w-full max-w-[400px] text-[12px] sm:text-[13px] md:text-[14px] lg:text-[16px] font-semibold leading-[1.5] md:leading-[24px] text-white">
            You're pre-qualified and off to a great start.
            <span className="hidden sm:inline"><br /></span>
            <span className="inline sm:hidden"> </span>
            Your trade-in offer and saved vehicles are ready
            <span className="hidden sm:inline"><br /></span>
            <span className="inline sm:hidden"> </span>
            — Let's Schedule a test drive.
          </p>
        </div>

        {/* Build cards array */}
        {(() => {
          const cards: React.ReactNode[] = [];
          
          // Great Start Card - Saved Vehicle
          if (savedVehicle) {
            cards.push(
              <div key="saved-vehicle" className="space-y-2 w-full lg:flex-1 lg:max-w-[416px]">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wide">
                  Great Start
                </h3>
                <Card className="overflow-hidden border-0 bg-[#FFF] backdrop-blur-sm w-full h-[160px] min-[1440px]:h-[220px] pb-[5px]">
                  <div className="flex flex-col h-full">
                    <div className="h-7 min-[1440px]:h-10 flex items-center justify-between px-3 min-[1440px]:px-4 bg-[#F2F2F2]">
                      {isPreQualified && (
                        <span className="inline-flex items-center gap-1.5 text-[11px] font-medium ">
                          <CheckCircleIcon size={14} className="h-3.5 w-3.5" />
                          Pre-Qualified
                        </span>
                      )}
                      <span className="text-[11px] font-medium text-gray-500 uppercase">
                        AUTO-FINANCING
                      </span>
                    </div>
                    <div className="flex gap-2 h-12 min-[1440px]:h-[72px] items-center px-3 min-[1440px]:px-4">
                      {savedVehicle.image && (
                        <div className="relative h-12 w-20 shrink-0 overflow-hidden rounded bg-gray-100">
                          <Image
                            src={savedVehicle.image}
                            alt={`${savedVehicle.year} ${savedVehicle.make} ${savedVehicle.model}`}
                            fill
                            className="object-cover"
                          />
                        </div>
                      )}
                      <div className="flex flex-col justify-center min-w-0">
                        <span className="text-[10px] text-gray-500">Approved Vehicle</span>
                        <p className="text-xs font-bold text-gray-900 truncate">
                          {savedVehicle.year} {savedVehicle.make} {savedVehicle.model}
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-cols-5 gap-1 h-9 min-[1440px]:h-12 items-center px-3 min-[1440px]:px-4 text-[10px] min-[1440px]:text-[11px] bg-gray-50">
                      <div>
                        <span className="text-gray-500">VIN</span>
                        <p className="font-semibold text-gray-900 truncate">
                          {savedVehicle.stockNumber || 'N/A'}
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500">Miles</span>
                        <p className="font-semibold text-gray-900">
                          {savedVehicle.mileage?.toLocaleString() || 'N/A'}
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500">Price</span>
                        <p className="font-semibold text-gray-900">
                          {formatPrice(savedVehicle.price)}
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500">Monthly</span>
                        <p className="font-semibold text-gray-900">$468</p>
                      </div>
                      <div>
                        <span className="text-gray-500">APR</span>
                        <p className="font-semibold text-gray-900">5.49%</p>
                      </div>
                    </div>
                    <div className="h-10 min-[1440px]:h-14 flex items-center px-3 min-[1440px]:px-4">
                      <Button
                        onClick={onBuyOnline}
                        className="w-full bg-red-600 text-white hover:bg-red-700 h-8 min-[1440px]:h-10 text-xs font-medium"
                      >
                        Buy Online
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            );
          }

          // Ready When You Are Card - Schedule Test Drive
          if (preQualifiedVehicle) {
            cards.push(
              <div key="test-drive" className="space-y-2 w-full lg:flex-1 lg:max-w-[416px]">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wide">
                  Ready When You Are
                </h3>
                <Card className="overflow-hidden border-0 bg-[#FFF] backdrop-blur-sm w-full h-[160px] min-[1440px]:h-[220px] pb-[5px]">
                  <div className="flex flex-col h-full">
                    <div className="h-7 min-[1440px]:h-10 flex items-center justify-between gap-2 px-3 min-[1440px]:px-4 bg-[#F2F2F2]">
                      <div className="flex items-center gap-1.5">
                        <CalendarIcon size={14} className="h-3.5 w-3.5 text-red-600" />
                        <span className="text-[11px] font-medium text-gray-900">
                          Schedule a Test Drive
                        </span>
                      </div>
                      <span className="text-[11px] font-medium text-gray-900">
                        3 SAVED VEHICLES
                      </span>
                    </div>
                    <div className="h-12 min-[1440px]:h-[72px] flex items-center px-3 min-[1440px]:px-4">
                      <p className="text-[11px] text-gray-500">Pre-Qualified: <span className="font-semibold text-gray-900 text-xs">{preQualifiedVehicle.year} {preQualifiedVehicle.make} {preQualifiedVehicle.model}</span></p>
                    </div>
                    <div className="h-9 min-[1440px]:h-12 flex items-center px-3 min-[1440px]:px-4 bg-gray-50">
                      <div className="flex items-start gap-1.5">
                        <LocationPinIcon size={14} className="h-3.5 w-3.5 text-red-600 mt-0.5 shrink-0" />
                        <div>
                          <p className="text-[11px] font-semibold text-gray-900">Toyota of Fort Worth, TX 76116</p>
                          <p className="text-[10px] text-gray-500">We are ready to schedule your test drive</p>
                        </div>
                      </div>
                    </div>
                    <div className="h-10 min-[1440px]:h-14 flex items-center px-3 min-[1440px]:px-4">
                      <Button
                        onClick={onScheduleTestDrive}
                        variant="outline"
                        className="w-full bg-gray-900 text-white hover:bg-gray-800 h-8 min-[1440px]:h-10 text-xs font-medium"
                      >
                        Book Test Drive
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            );
          }

          // Don't Miss Out Card - Trade-In Offer
          if (tradeInOffer) {
            cards.push(
              <div key="trade-in" className="space-y-2 w-full lg:flex-1 lg:max-w-[416px]">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wide">
                  Don't Miss Out
                </h3>
                <Card className="overflow-hidden border-0 bg-[#fff] backdrop-blur-sm w-full h-[160px] min-[1440px]:h-[220px] pb-[5px]">
                  <div className="flex flex-col h-full">
                    <div className="h-7 min-[1440px]:h-10 flex items-center gap-2 px-3 min-[1440px]:px-4 bg-[#F2F2F2]">
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-orange-700">
                        <ClockIcon size={14} className="h-3.5 w-3.5" />
                        Trade-In Offer
                      </span>
                    </div>
                    <div className="h-12 min-[1440px]:h-[72px] flex justify-center items-center px-3 min-[1440px]:px-4 text-xl min-[1440px]:text-2xl gap-1.5">
                      <p className="text-xl font-bold text-primary">
                        {formatPrice(tradeInOffer.offerAmount)}
                      </p>
                      <p className="text-xs text-gray-600 flex justify-center items-center gap-1">
                        {tradeInOffer.year} {tradeInOffer.make} {tradeInOffer.model}
                      </p>
                    </div>
                    <div className="h-9 min-[1440px]:h-12 bg-gray-50 flex justify-center items-center px-3 min-[1440px]:px-4">
                      <div className="flex items-center gap-1.5">
                        <ClockIcon size={14} className="h-3.5 w-3.5 text-orange-500 shrink-0" />
                        <span className="text-[11px] font-semibold text-gray-900">
                          Expires in {tradeInOffer.expiresInDays} days
                        </span>
                        <span className="text-[10px] text-gray-500">
                          Don't miss out on this offer!
                        </span>
                      </div>
                    </div>
                    <div className="h-10 min-[1440px]:h-14 flex items-center px-3 min-[1440px]:px-4">
                      <Button
                        onClick={onAcceptOffer}
                        className="w-full bg-gray-900 text-white hover:bg-gray-800 h-8 min-[1440px]:h-10 text-xs font-medium"
                      >
                        Accept Offer Now
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            );
          }

          return (
            <>
              {/* Mobile Carousel - shown on screens < lg */}
              <div className="block lg:hidden mt-6 w-full">
                <Carousel opts={{ align: 'start', loop: true }} className="w-full">
                  <CarouselContent className="-ml-4">
                    {cards.map((card, index) => (
                      <CarouselItem key={index} className="pl-4 basis-[92%] sm:basis-[80%] md:basis-[60%]">
                        {card}
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <CarouselDots className="pt-4 gap-3 [&>button]:h-2 [&>button]:w-2 [&>button]:rounded-full [&>button]:transition-all [&>button]:bg-white/40 [&>button]:hover:bg-white/60 [&>button[class~='w-6']]:w-2 [&>button[class~='w-6']]:bg-white [&>button[class~='w-6']]:ring-2 [&>button[class~='w-6']]:ring-white [&>button[class~='w-6']]:ring-offset-2 [&>button[class~='w-6']]:ring-offset-transparent" />
                </Carousel>
              </div>

              {/* Desktop Flex Layout - shown on screens >= lg */}
              <div className="hidden lg:flex gap-2 mt-12 flex-row w-full">
                {cards}
              </div>
            </>
          );
        })()}

        {/* Continue Shopping Button */}
        <div className="flex pt-4 lg:pt-6 justify-center items-center w-full">
          <Button
            onClick={onContinueShopping}
            variant="outline"
            className="border-white/30 bg-[#fff] text-black backdrop-blur-sm px-8 lg:px-12 h-9 lg:h-10 text-xs lg:text-sm"
          >
            Continue Shopping
          </Button>
        </div>
      </div>
    </div>
  )
}
