export { SearchClient } from './search-client';
export { SearchWrapper } from './search-wrapper';
export type { SearchPageData, Vehicle, FilterSections } from '@/lib/search/data';
