/**
 * VDP (Vehicle Detail Page) — shared type definitions.
 *
 * These types describe the *data shape* only.
 * Components are responsible for mapping data → icons / JSX.
 */

// ---------------------------------------------------------------------------
// Vehicle detail (the main entity)
// ---------------------------------------------------------------------------

export interface VehicleDetail {
  year: number
  make: string
  model: string
  trim: string
  price: number
  originalPrice: number
  condition: string
  warranty: boolean
  inspected: boolean
  miles: string
  drivetrain: string
  mpg: string
  stock: string
  vin: string
  exteriorColor: string
  interiorColor: string
  dealer: {
    name: string
    location: string
    distance: string
  }
  images: string[]
  highlights: string[]
}

// ---------------------------------------------------------------------------
// Vehicle specs (Overview tab)
// ---------------------------------------------------------------------------

/** `key` maps to an icon in the component layer (e.g. "engine" → <EngineIcon />) */
export interface VehicleSpecData {
  key: string
  label: string
  value: string
}

// ---------------------------------------------------------------------------
// Feature categories (Features & Details tab)
// ---------------------------------------------------------------------------

export interface FeatureCategory {
  name: string
  features: string[]
}

// ---------------------------------------------------------------------------
// Pricing data (Pricing tab)
// ---------------------------------------------------------------------------

export interface PricingData {
  currentPrice: number
  avgPrice: number
  daysOnSite: number
  views: number
  saves: number
}

// ---------------------------------------------------------------------------
// History data (History tab)
// ---------------------------------------------------------------------------

export interface HistoryData {
  vin: string
  vehicleDescription: string
  damageReported: number
  previousOwners: number
  servicesOnRecord: number
  repairsReported: number
  ownerTypes: string[]
  lastOdometerReading: number
}

// ---------------------------------------------------------------------------
// Rating data
// ---------------------------------------------------------------------------

export interface RatingDistribution {
  stars: number
  count: number
}

export interface RatingData {
  rating: number
  reviewCount: number
  distribution: RatingDistribution[]
}

// ---------------------------------------------------------------------------
// Complete VDP page payload — everything needed to render the full page
// ---------------------------------------------------------------------------

export interface VdpPageData {
  vehicle: VehicleDetail
  specs: VehicleSpecData[]
  features: FeatureCategory[]
  pricing: PricingData
  history: HistoryData
  rating: RatingData
}
