/**
 * Minimal Tailwind config stub for shadcn schema validation
 *
 * Note: This project uses Tailwind CSS v4 with CSS-based configuration.
 * The actual Tailwind configuration is in src/styles.css using @theme directive.
 * This file exists only to satisfy the shadcn components.json schema.
 */
export default {}
